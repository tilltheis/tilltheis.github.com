var localizedStrings = {
    'Monday': 'Maanantai',
    'Tuesday': 'Tiistai',
    'Wednesday': 'Keskiviikko',
    'Thursday': 'Torstai',
    'Friday': 'Perjantai'
};
