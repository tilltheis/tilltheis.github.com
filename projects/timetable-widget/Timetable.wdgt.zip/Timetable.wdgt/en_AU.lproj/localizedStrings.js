var localizedStrings = {
    '%y-%m-%d': '%d/%m/%y',
    
    "%time-phrase%": "at %d AM",
    'at 0 AM' : 'at 12 AM',
    'at 12 AM': 'at 12 PM',
    'at 13 AM': 'at 1 PM',
    'at 14 AM': 'at 2 PM',
    'at 15 AM': 'at 3 PM',
    'at 16 AM': 'at 4 PM',
    'at 17 AM': 'at 5 PM',
    'at 18 AM': 'at 6 PM',
    'at 19 AM': 'at 7 PM',
    'at 20 AM': 'at 8 PM',
    'at 21 AM': 'at 9 PM',
    'at 22 AM': 'at 10 PM',
    'at 23 AM': 'at 11 PM'
};
